﻿namespace Application.Constants
{
    public class Constants
    {
        public const string speakerPhotosPath = @"SpeakersPhotos";
    }
}