﻿namespace PlanificatorCMD.Utils
{
    public static class ExecutionResult
    {
        public static int Fail => 1;
        public static int Succes => 0;
    }
}