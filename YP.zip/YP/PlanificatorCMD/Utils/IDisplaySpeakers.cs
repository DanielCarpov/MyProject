﻿namespace PlanificatorCMD.Utils
{
    public interface IDisplaySpeakers
    {
        int DisplayAllSpeakers(bool displayOption);
    }
}