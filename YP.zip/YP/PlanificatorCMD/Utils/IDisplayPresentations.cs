﻿namespace PlanificatorCMD.Utils
{
    public interface IDisplayPresentations
    {
        int DisplayAllPresentations(bool displayOption);
    }
}