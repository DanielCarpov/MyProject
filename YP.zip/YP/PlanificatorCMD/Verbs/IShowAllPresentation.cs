﻿namespace PlanificatorCMD.Verbs
{
    public interface IShowAllPresentation
    {
        bool DisplayOption { get; set; }
    }
}