﻿namespace PlanificatorCMD.Verbs
{
    public interface IShowAllSpeakersVerb
    {
        public bool DisplayOption { get; set; }
    }
}