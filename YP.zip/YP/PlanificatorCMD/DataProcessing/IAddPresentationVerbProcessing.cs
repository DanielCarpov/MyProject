﻿using PlanificatorCMD.Verbs;

namespace PlanificatorCMD.DataProcessing
{
    public interface IAddPresentationVerbProcessing
    {
        int AddPresentation(IAddPresentationVerb addPresentationVerb);
    }
}