﻿namespace PlanificatorCMD.DataProcessing
{
    public interface IPhotoPathProcessing
    {
        string PhotoCopy(string photoPath);
    }
}