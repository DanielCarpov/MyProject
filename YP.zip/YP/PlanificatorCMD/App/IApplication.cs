﻿namespace PlanificatorCMD
{
    public interface IApplication
    {
        void Run(string[] args);
    }
}